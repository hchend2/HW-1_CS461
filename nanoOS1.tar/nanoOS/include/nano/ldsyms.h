// Symbols set in the linker script.
// Mar-2008: Andrei Warkentin

#ifndef __LDSYMS_H__
#define __LDSYMS_H__

extern char _text, _etext, _edata, _end, _pagefault_fixups, _pagefault_fixups_end;

#endif

