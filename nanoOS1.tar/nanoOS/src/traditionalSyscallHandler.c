#include <nano/types.h>
#include <nano/cpuPrivileged.h>


void
traditionalSyscallHandler(arch_interrupt_regs_t *regs) {
}



