
const char kernel_version[]="nanoOS v0.0";
